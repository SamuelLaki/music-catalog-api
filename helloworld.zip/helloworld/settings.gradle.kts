rootProject.name="helloworld"
